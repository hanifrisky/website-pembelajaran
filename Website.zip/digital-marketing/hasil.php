<?php
// Set session params to persist cookie for 24 hours (86400 seconds)
session_set_cookie_params(86400);
session_start();

// Admin Password Configuration
$admin_password = 'Cdxfs1qaz'; 

$error = '';
$csv_file = 'hasil_game_tim.csv';

// Handle Login Submission
if (isset($_POST['password'])) {
    if ($_POST['password'] === $admin_password) {
        $_SESSION['loggedin_dm'] = true;
        $_SESSION['login_time_dm'] = time();
        header("Location: hasil.php");
        exit();
    } else {
        $error = 'Kata sandi salah!';
    }
}

// Handle Logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    unset($_SESSION['loggedin_dm']);
    unset($_SESSION['login_time_dm']);
    header("Location: hasil.php");
    exit();
}

// Check Authentication and 24-hour Expiry
$is_authenticated = false;
if (isset($_SESSION['loggedin_dm']) && $_SESSION['loggedin_dm'] === true) {
    if (time() - $_SESSION['login_time_dm'] < 86400) {
        $is_authenticated = true;
    } else {
        unset($_SESSION['loggedin_dm']);
        unset($_SESSION['login_time_dm']);
        $error = 'Sesi Anda telah berakhir (24 jam). Harap masuk kembali.';
    }
}

// Actions once Authenticated
if ($is_authenticated) {
    // 1. Download CSV
    if (isset($_GET['action']) && $_GET['action'] === 'download') {
        if (file_exists($csv_file)) {
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=hasil_game_tim_digital_marketing.csv');
            readfile($csv_file);
            exit();
        } else {
            header("Location: hasil.php");
            exit();
        }
    }

    // 2. Clear All Submissions
    if (isset($_POST['action']) && $_POST['action'] === 'clear_all') {
        if (file_exists($csv_file)) {
            unlink($csv_file);
        }
        header("Location: hasil.php");
        exit();
    }

    // 3. Delete Specific Row
    if (isset($_POST['action']) && $_POST['action'] === 'delete_row') {
        $row_idx = isset($_POST['row_idx']) ? intval($_POST['row_idx']) : -1;
        if ($row_idx >= 0 && file_exists($csv_file)) {
            $temp_rows = [];
            if (($handle = fopen($csv_file, "r")) !== FALSE) {
                // Skip BOM
                $bom = fread($handle, 3);
                if ($bom !== "\xEF\xBB\xBF") {
                    rewind($handle);
                }
                $header = fgetcsv($handle);
                $idx = 0;
                while (($data = fgetcsv($handle)) !== FALSE) {
                    if ($idx !== $row_idx) {
                        $temp_rows[] = $data;
                    }
                    $idx++;
                }
                fclose($handle);
            }

            // Rewrite CSV file
            $f = fopen($csv_file, 'w');
            if ($f !== false) {
                fputs($f, "\xEF\xBB\xBF"); // BOM UTF-8
                fputcsv($f, ['Waktu', 'Nama Kelompok', 'Skenario', 'Draft Respons']);
                foreach ($temp_rows as $row) {
                    fputcsv($f, $row);
                }
                fclose($f);
            }
        }
        header("Location: hasil.php");
        exit();
    }
}

// If not authenticated, render Login Screen
if (!$is_authenticated):
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Akses Terproteksi - Dashboard Game DM</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #C9F13B; /* Neon Lime */
      --primary-hover: #b0d42c;
      --bg-dark: #050a07; /* Forest Dark background */
      --card-bg: rgba(255, 255, 255, 0.03);
      --border-glass: rgba(255, 255, 255, 0.08);
      --border-glass-focus: rgba(201, 241, 59, 0.4);
      --text-main: #f3f4f6;
      --text-secondary: #9ca3af;
      --font-display: 'Space Grotesk', sans-serif;
      --font-body: 'Manrope', sans-serif;
      --danger: #ef4444;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: var(--font-body);
      background-color: var(--bg-dark);
      color: var(--text-main);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    /* Cyberpunk Grid Overlay */
    body::before {
      content: "";
      position: absolute; inset: 0;
      background-image: linear-gradient(rgba(255,255,255,0.005) 1px, transparent 1px),
                        linear-gradient(90deg, rgba(255,255,255,0.005) 1px, transparent 1px);
      background-size: 40px 40px;
      pointer-events: none;
      z-index: 0;
    }

    .login-container {
      background: rgba(255, 255, 255, 0.02);
      border: 1px solid var(--border-glass);
      backdrop-filter: blur(12px);
      padding: 40px;
      border-radius: 24px;
      width: 100%;
      max-width: 420px;
      text-align: center;
      box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
      z-index: 10;
      position: relative;
    }

    .login-container::before {
      content: "";
      position: absolute; top: 0; left: 0; right: 0; height: 4px;
      background: var(--primary);
      border-radius: 24px 24px 0 0;
    }

    .logo-icon {
      font-size: 3rem;
      margin-bottom: 20px;
      display: inline-block;
    }

    h1 {
      font-family: var(--font-display);
      font-size: 1.8rem;
      font-weight: 700;
      margin-bottom: 8px;
      letter-spacing: -0.01em;
    }

    .subtitle {
      font-size: 0.9rem;
      color: var(--text-secondary);
      margin-bottom: 30px;
      line-height: 1.5;
    }

    .form-group {
      margin-bottom: 20px;
      text-align: left;
    }

    label {
      display: block;
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 8px;
      color: var(--text-secondary);
    }

    input[type="password"] {
      width: 100%;
      padding: 14px 18px;
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid var(--border-glass);
      color: var(--text-main);
      font-family: var(--font-body);
      font-size: 1rem;
      transition: all 0.2s ease;
      outline: none;
    }

    input[type="password"]:focus {
      border-color: var(--primary);
      box-shadow: 0 0 12px rgba(201, 241, 59, 0.15);
      background: rgba(255, 255, 255, 0.08);
    }

    .btn-submit {
      width: 100%;
      padding: 14px;
      border-radius: 12px;
      border: none;
      background: var(--primary);
      color: #000000;
      font-family: var(--font-display);
      font-weight: 700;
      font-size: 1rem;
      cursor: pointer;
      box-shadow: 0 4px 14px rgba(201, 241, 59, 0.25);
      transition: all 0.2s ease;
    }

    .btn-submit:hover {
      background: var(--primary-hover);
      box-shadow: 0 6px 20px rgba(201, 241, 59, 0.4);
    }

    .error-msg {
      margin-top: 15px;
      color: var(--danger);
      font-size: 0.85rem;
      font-weight: 600;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <span class="logo-icon">📊</span>
    <h1>Admin Lock</h1>
    <p class="subtitle">Silakan masukkan kata sandi guru untuk masuk ke Dashboard Hasil Game Kelompok.</p>
    <form method="POST">
      <div class="form-group">
        <label for="password">Kata Sandi Guru:</label>
        <input type="password" id="password" name="password" placeholder="••••••••" required autofocus>
      </div>
      <button type="submit" class="btn-submit">🔓 Buka Dashboard</button>
    </form>
    <?php if (!empty($error)): ?>
      <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
  </div>
</body>
</html>
<?php
exit();
endif;

// --- AUTHENTICATED ADMIN DASHBOARD VIEW ---
$submissions = [];
if (file_exists($csv_file)) {
    if (($handle = fopen($csv_file, "r")) !== FALSE) {
        $bom = fread($handle, 3);
        if ($bom !== "\xEF\xBB\xBF") {
            rewind($handle);
        }
        $header = fgetcsv($handle);
        $idx = 0;
        while (($data = fgetcsv($handle)) !== FALSE) {
            if (count($data) >= 4) {
                $submissions[] = [
                    'original_idx' => $idx,
                    'waktu' => $data[0],
                    'nama_tim' => $data[1],
                    'skenario' => $data[2],
                    'respons' => $data[3]
                ];
            }
            $idx++;
        }
        fclose($handle);
    }
}
// Sort newest first
$submissions_reversed = array_reverse($submissions);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Hasil Game - Digital Marketing</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #C9F13B;
      --primary-hover: #b0d42c;
      --bg-dark: #050a07;
      --card-bg: rgba(255, 255, 255, 0.02);
      --border-glass: rgba(255, 255, 255, 0.08);
      --text-main: #f3f4f6;
      --text-secondary: #9ca3af;
      --danger: #ef4444;
      --danger-hover: #dc2626;
      --font-display: 'Space Grotesk', sans-serif;
      --font-body: 'Manrope', sans-serif;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: var(--font-body);
      background-color: var(--bg-dark);
      color: var(--text-main);
      min-height: 100vh;
      padding: 40px 20px;
    }

    body::before {
      content: "";
      position: absolute; inset: 0;
      background-image: linear-gradient(rgba(255,255,255,0.003) 1px, transparent 1px),
                        linear-gradient(90deg, rgba(255,255,255,0.003) 1px, transparent 1px);
      background-size: 50px 50px;
      pointer-events: none;
      z-index: -1;
    }

    .container {
      max-width: 1100px;
      margin: 0 auto;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      margin-bottom: 40px;
      border-bottom: 1px solid var(--border-glass);
      padding-bottom: 24px;
    }

    h1 {
      font-family: var(--font-display);
      font-size: 2.2rem;
      font-weight: 700;
      letter-spacing: -0.02em;
    }
    h1 span { color: var(--primary); }

    .header-actions {
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
    }

    .btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 10px 18px;
      border-radius: 8px;
      font-family: var(--font-display);
      font-weight: 700;
      font-size: 0.85rem;
      text-decoration: none;
      cursor: pointer;
      transition: all 0.2s;
      border: none;
    }

    .btn-back {
      background: rgba(255,255,255,0.05);
      border: 1px solid var(--border-glass);
      color: var(--text-main);
    }
    .btn-back:hover { background: rgba(255,255,255,0.1); }

    .btn-primary {
      background: var(--primary);
      color: #000000;
      box-shadow: 0 4px 12px rgba(201, 241, 59, 0.2);
    }
    .btn-primary:hover {
      background: var(--primary-hover);
      box-shadow: 0 6px 18px rgba(201, 241, 59, 0.35);
    }

    .btn-danger {
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.2);
      color: var(--danger);
    }
    .btn-danger:hover {
      background: var(--danger);
      color: white;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }

    .stat-card {
      background: var(--card-bg);
      border: 1px solid var(--border-glass);
      border-radius: 16px;
      padding: 20px;
      backdrop-filter: blur(10px);
    }
    .stat-card h3 {
      font-size: 0.75rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--text-secondary);
      margin-bottom: 8px;
    }
    .stat-card .value {
      font-family: var(--font-display);
      font-size: 1.8rem;
      font-weight: 700;
      color: var(--primary);
    }

    .table-container {
      background: var(--card-bg);
      border: 1px solid var(--border-glass);
      border-radius: 20px;
      overflow: hidden;
      margin-bottom: 40px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
    }

    th {
      font-family: var(--font-display);
      font-size: 0.8rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--text-secondary);
      background: rgba(255,255,255,0.01);
      padding: 18px 24px;
      border-bottom: 1px solid var(--border-glass);
    }

    td {
      padding: 18px 24px;
      border-bottom: 1px solid var(--border-glass);
      font-size: 0.9rem;
      line-height: 1.5;
      vertical-align: top;
    }

    tr:last-child td {
      border-bottom: none;
    }

    .waktu-col { color: var(--text-secondary); font-size: 0.8rem; white-space: nowrap; }
    .tim-col { font-weight: 700; color: var(--primary); }
    .skenario-col { font-weight: 600; white-space: nowrap; }
    .respons-col { max-width: 450px; word-break: break-word; }

    .no-data {
      text-align: center;
      padding: 60px 24px;
      color: var(--text-secondary);
    }
    .no-data span {
      display: block;
      font-size: 3rem;
      margin-bottom: 12px;
    }

    .btn-delete-row {
      background: transparent;
      border: none;
      color: var(--danger);
      cursor: pointer;
      font-size: 0.85rem;
      font-weight: 700;
      transition: opacity 0.2s;
    }
    .btn-delete-row:hover { opacity: 0.8; text-decoration: underline; }

    @media (max-width: 768px) {
      header { flex-direction: column; align-items: flex-start; }
      table, thead, tbody, th, td, tr { display: block; }
      th { display: none; }
      tr { border-bottom: 1px solid var(--border-glass); padding: 15px 0; }
      td { border-bottom: none; padding: 6px 20px; }
      td::before {
        content: attr(data-label);
        display: block;
        font-size: 0.7rem;
        font-weight: 800;
        text-transform: uppercase;
        color: var(--text-secondary);
        margin-bottom: 4px;
      }
    }
  </style>
</head>
<body>

  <div class="container">
    <header>
      <div>
        <h1>Dashboard Game <span>War Room</span></h1>
        <p style="color: var(--text-secondary); font-size: 0.95rem; margin-top: 4px;">Rekapitulasi Draf Respons Etis yang Diajukan Kelompok secara Real-Time.</p>
      </div>
      <div class="header-actions">
        <a href="index.html" class="btn btn-back">🏠 Kembali ke Portal</a>
        <?php if (!empty($submissions)): ?>
          <a href="hasil.php?action=download" class="btn btn-primary">📥 Unduh Excel / CSV</a>
          <form method="POST" style="display:inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus SEMUA jawaban kelompok?');">
            <input type="hidden" name="action" value="clear_all">
            <button type="submit" class="btn btn-danger">⚠️ Reset Semua Data</button>
          </form>
        <?php endif; ?>
        <a href="hasil.php?action=logout" class="btn btn-back" style="color: var(--danger);">🚪 Keluar</a>
      </div>
    </header>

    <div class="stats-grid">
      <div class="stat-card">
        <h3>Total Tim Mengirim</h3>
        <div class="value"><?php echo count($submissions); ?> Kelompok</div>
      </div>
      <div class="stat-card">
        <h3>Modul Kasus</h3>
        <div class="value" style="color: white;">Etika &amp; Netiket</div>
      </div>
    </div>

    <div class="table-container">
      <?php if (empty($submissions)): ?>
        <div class="no-data">
          <span>📦</span>
          <p>Belum ada jawaban dari kelompok/tim.</p>
          <p style="font-size: 0.8rem; margin-top: 5px; opacity: 0.6;">Draf klarifikasi siswa akan muncul otomatis di sini setelah dikirim dari Slide 11 presentasi.</p>
        </div>
      <?php else: ?>
        <table>
          <thead>
            <tr>
              <th style="width: 60px;">No</th>
              <th style="width: 140px;">Waktu Kirim</th>
              <th style="width: 180px;">Nama Kelompok</th>
              <th style="width: 220px;">Skenario Kasus</th>
              <th>Draf Respons Klarifikasi</th>
              <th style="width: 80px; text-align: center;">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $no = 1;
            foreach ($submissions_reversed as $row): 
            ?>
              <tr>
                <td data-label="No" style="font-family: var(--font-display); font-weight: 700;"><?php echo $no++; ?></td>
                <td data-label="Waktu Kirim" class="waktu-col"><?php echo htmlspecialchars($row['waktu']); ?></td>
                <td data-label="Nama Kelompok" class="tim-col"><?php echo htmlspecialchars($row['nama_tim']); ?></td>
                <td data-label="Skenario Kasus" class="skenario-col"><?php echo htmlspecialchars($row['skenario']); ?></td>
                <td data-label="Draf Respons" class="respons-col"><?php echo nl2br(htmlspecialchars($row['respons'])); ?></td>
                <td data-label="Aksi" style="text-align: center;">
                  <form method="POST" style="display:inline;" onsubmit="return confirm('Hapus baris jawaban ini?');">
                    <input type="hidden" name="action" value="delete_row">
                    <input type="hidden" name="row_idx" value="<?php echo $row['original_idx']; ?>">
                    <button type="submit" class="btn-delete-row">Hapus</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>

</body>
</html>
